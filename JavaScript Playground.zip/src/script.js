const message = 'Hello world' // Try edit me

// Update header text
document.querySelector('#header').innerHTML = message

//1
console.log('Hello World');

//2
const instruments = ['violin', 'piano', 'chello'];
console.log(instruments);

//3
for (let i=0; i<3; i++){
  console.log(instruments[i]);
}

//4
let number=1;
while (number <= 100) {
  console.log(number);
  number += 1;
}